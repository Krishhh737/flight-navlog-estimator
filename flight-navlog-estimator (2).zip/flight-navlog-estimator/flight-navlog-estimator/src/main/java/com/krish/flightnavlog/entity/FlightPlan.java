package com.krish.flightnavlog.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "flight_plans")
public class FlightPlan {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable=false)
    private String pilotName;
    @Column(nullable=false)
    private String departure;
    @Column(nullable=false)
    private String destination;
    private double totalDistanceNm;
    private double totalEteMinutes;
    private double tripFuelGallons;
    private double reserveFuelGallons;
    private double totalFuelRequiredGallons;

    @Lob
    @Column(columnDefinition = "LONGTEXT")
    private String navLogJson;

    private LocalDateTime createdAt;

    public FlightPlan() {}
    @PrePersist
    public void prePersist() { if (createdAt == null) createdAt = LocalDateTime.now(); }

    public Long getId() { return id; }
    public void setId(Long id) { this.id=id; }
    public String getPilotName() { return pilotName; }
    public void setPilotName(String pilotName) { this.pilotName=pilotName; }
    public String getDeparture() { return departure; }
    public void setDeparture(String departure) { this.departure=departure; }
    public String getDestination() { return destination; }
    public void setDestination(String destination) { this.destination=destination; }
    public double getTotalDistanceNm() { return totalDistanceNm; }
    public void setTotalDistanceNm(double v) { this.totalDistanceNm=v; }
    public double getTotalEteMinutes() { return totalEteMinutes; }
    public void setTotalEteMinutes(double v) { this.totalEteMinutes=v; }
    public double getTripFuelGallons() { return tripFuelGallons; }
    public void setTripFuelGallons(double v) { this.tripFuelGallons=v; }
    public double getReserveFuelGallons() { return reserveFuelGallons; }
    public void setReserveFuelGallons(double v) { this.reserveFuelGallons=v; }
    public double getTotalFuelRequiredGallons() { return totalFuelRequiredGallons; }
    public void setTotalFuelRequiredGallons(double v) { this.totalFuelRequiredGallons=v; }
    public String getNavLogJson() { return navLogJson; }
    public void setNavLogJson(String navLogJson) { this.navLogJson=navLogJson; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt=createdAt; }
}
