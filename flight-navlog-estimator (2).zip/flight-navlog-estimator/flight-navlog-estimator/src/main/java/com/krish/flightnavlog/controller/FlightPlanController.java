package com.krish.flightnavlog.controller;

import java.util.List;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.krish.flightnavlog.model.*;
import com.krish.flightnavlog.service.FlightPlanService;

@RestController
@RequestMapping("/api/flight-plans")
public class FlightPlanController {
    private final FlightPlanService service;
    public FlightPlanController(FlightPlanService service) { this.service = service; }

    @PostMapping
    public ResponseEntity<FlightPlanResult> create(@Valid @RequestBody FlightPlanRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(service.create(request));
    }

    @GetMapping
    public List<FlightPlanResult> all() { return service.getAll(); }

    @GetMapping("/{id}")
    public ResponseEntity<FlightPlanResult> byId(@PathVariable Long id) {
        FlightPlanResult result = service.getById(id);
        return result == null ? ResponseEntity.notFound().build() : ResponseEntity.ok(result);
    }
}
