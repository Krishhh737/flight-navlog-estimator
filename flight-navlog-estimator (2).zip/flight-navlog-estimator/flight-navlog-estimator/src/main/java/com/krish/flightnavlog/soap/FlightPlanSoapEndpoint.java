package com.krish.flightnavlog.soap;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Source;
import javax.xml.transform.dom.DOMSource;
import org.springframework.stereotype.Component;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import com.krish.flightnavlog.model.FlightPlanResult;
import com.krish.flightnavlog.service.FlightPlanService;

@Endpoint
@Component
public class FlightPlanSoapEndpoint {
    private static final String NS = "http://krish.com/flightnavlog/soap";
    private final FlightPlanService service;

    public FlightPlanSoapEndpoint(FlightPlanService service) { this.service = service; }

    @PayloadRoot(namespace = NS, localPart = "getFlightPlanRequest")
    @ResponsePayload
    public Source getFlightPlan(@RequestPayload Source request) throws Exception {
        javax.xml.transform.Transformer transformer =
                javax.xml.transform.TransformerFactory.newInstance().newTransformer();
        javax.xml.transform.dom.DOMResult domResult = new javax.xml.transform.dom.DOMResult();
        transformer.transform(request, domResult);
        Element root = (Element) ((Document) domResult.getNode()).getDocumentElement();
        String idText = root.getElementsByTagNameNS(NS, "id").item(0).getTextContent().trim();
        Long id = Long.parseLong(idText);
        FlightPlanResult plan = service.getById(id);

        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        factory.setNamespaceAware(true);
        Document doc = factory.newDocumentBuilder().newDocument();
        Element response = doc.createElementNS(NS, "getFlightPlanResponse");
        doc.appendChild(response);

        if (plan == null) {
            append(doc, response, "found", "false");
            append(doc, response, "message", "No flight plan found for id " + id);
        } else {
            append(doc, response, "found", "true");
            append(doc, response, "id", String.valueOf(plan.getId()));
            append(doc, response, "pilotName", plan.getPilotName());
            append(doc, response, "departure", plan.getDeparture());
            append(doc, response, "destination", plan.getDestination());
            append(doc, response, "totalDistanceNm", String.valueOf(plan.getTotalDistanceNm()));
            append(doc, response, "totalEteMinutes", String.valueOf(plan.getTotalEteMinutes()));
            append(doc, response, "tripFuelGallons", String.valueOf(plan.getTripFuelGallons()));
            append(doc, response, "reserveFuelGallons", String.valueOf(plan.getReserveFuelGallons()));
            append(doc, response, "totalFuelRequiredGallons", String.valueOf(plan.getTotalFuelRequiredGallons()));
        }
        return new DOMSource(doc);
    }

    private void append(Document doc, Element parent, String name, String value) {
        Element child = doc.createElementNS(NS, name);
        child.setTextContent(value == null ? "" : value);
        parent.appendChild(child);
    }
}
