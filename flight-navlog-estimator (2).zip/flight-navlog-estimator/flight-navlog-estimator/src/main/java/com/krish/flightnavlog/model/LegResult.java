package com.krish.flightnavlog.model;

public class LegResult {
    private String from;
    private String to;
    private double distanceNm;
    private double trueCourseDeg;
    private double windCorrectionAngleDeg;
    private double groundSpeedKt;
    private double trueHeadingDeg;
    private double magneticHeadingDeg;
    private double eteMinutes;
    private double fuelGallons;

    public LegResult() {}
    public LegResult(String from, String to, double distanceNm, double trueCourseDeg,
                     double windCorrectionAngleDeg, double groundSpeedKt,
                     double trueHeadingDeg, double magneticHeadingDeg,
                     double eteMinutes, double fuelGallons) {
        this.from=from; this.to=to; this.distanceNm=distanceNm;
        this.trueCourseDeg=trueCourseDeg; this.windCorrectionAngleDeg=windCorrectionAngleDeg;
        this.groundSpeedKt=groundSpeedKt; this.trueHeadingDeg=trueHeadingDeg;
        this.magneticHeadingDeg=magneticHeadingDeg; this.eteMinutes=eteMinutes;
        this.fuelGallons=fuelGallons;
    }
    public String getFrom() { return from; }
    public void setFrom(String from) { this.from = from; }
    public String getTo() { return to; }
    public void setTo(String to) { this.to = to; }
    public double getDistanceNm() { return distanceNm; }
    public void setDistanceNm(double distanceNm) { this.distanceNm = distanceNm; }
    public double getTrueCourseDeg() { return trueCourseDeg; }
    public void setTrueCourseDeg(double trueCourseDeg) { this.trueCourseDeg = trueCourseDeg; }
    public double getWindCorrectionAngleDeg() { return windCorrectionAngleDeg; }
    public void setWindCorrectionAngleDeg(double windCorrectionAngleDeg) { this.windCorrectionAngleDeg = windCorrectionAngleDeg; }
    public double getGroundSpeedKt() { return groundSpeedKt; }
    public void setGroundSpeedKt(double groundSpeedKt) { this.groundSpeedKt = groundSpeedKt; }
    public double getTrueHeadingDeg() { return trueHeadingDeg; }
    public void setTrueHeadingDeg(double trueHeadingDeg) { this.trueHeadingDeg = trueHeadingDeg; }
    public double getMagneticHeadingDeg() { return magneticHeadingDeg; }
    public void setMagneticHeadingDeg(double magneticHeadingDeg) { this.magneticHeadingDeg = magneticHeadingDeg; }
    public double getEteMinutes() { return eteMinutes; }
    public void setEteMinutes(double eteMinutes) { this.eteMinutes = eteMinutes; }
    public double getFuelGallons() { return fuelGallons; }
    public void setFuelGallons(double fuelGallons) { this.fuelGallons = fuelGallons; }
}
