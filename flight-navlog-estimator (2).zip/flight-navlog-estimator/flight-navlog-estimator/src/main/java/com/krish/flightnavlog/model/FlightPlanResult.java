package com.krish.flightnavlog.model;

import java.util.List;

public class FlightPlanResult {
    private Long id;
    private String pilotName;
    private String departure;
    private String destination;
    private double totalDistanceNm;
    private double totalEteMinutes;
    private double tripFuelGallons;
    private double reserveFuelGallons;
    private double totalFuelRequiredGallons;
    private List<LegResult> legs;

    public FlightPlanResult() {}
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getPilotName() { return pilotName; }
    public void setPilotName(String pilotName) { this.pilotName = pilotName; }
    public String getDeparture() { return departure; }
    public void setDeparture(String departure) { this.departure = departure; }
    public String getDestination() { return destination; }
    public void setDestination(String destination) { this.destination = destination; }
    public double getTotalDistanceNm() { return totalDistanceNm; }
    public void setTotalDistanceNm(double totalDistanceNm) { this.totalDistanceNm = totalDistanceNm; }
    public double getTotalEteMinutes() { return totalEteMinutes; }
    public void setTotalEteMinutes(double totalEteMinutes) { this.totalEteMinutes = totalEteMinutes; }
    public double getTripFuelGallons() { return tripFuelGallons; }
    public void setTripFuelGallons(double tripFuelGallons) { this.tripFuelGallons = tripFuelGallons; }
    public double getReserveFuelGallons() { return reserveFuelGallons; }
    public void setReserveFuelGallons(double reserveFuelGallons) { this.reserveFuelGallons = reserveFuelGallons; }
    public double getTotalFuelRequiredGallons() { return totalFuelRequiredGallons; }
    public void setTotalFuelRequiredGallons(double totalFuelRequiredGallons) { this.totalFuelRequiredGallons = totalFuelRequiredGallons; }
    public List<LegResult> getLegs() { return legs; }
    public void setLegs(List<LegResult> legs) { this.legs = legs; }
}
