package com.krish.flightnavlog.service;

import java.util.List;
import org.springframework.stereotype.Service;
import com.krish.flightnavlog.entity.FlightPlan;
import com.krish.flightnavlog.model.*;
import com.krish.flightnavlog.repository.FlightPlanRepository;

@Service
public class FlightPlanService {
    private final NavigationCalculatorService calculator;
    private final FlightPlanRepository repository;

    public FlightPlanService(NavigationCalculatorService calculator, FlightPlanRepository repository) {
        this.calculator = calculator; this.repository = repository;
    }

    public FlightPlanResult create(FlightPlanRequest request) {
        FlightPlanResult result = calculator.calculate(request);
        FlightPlan saved = repository.save(calculator.saveEntity(request, result));
        result.setId(saved.getId());
        return result;
    }

    public FlightPlanResult getById(Long id) {
        return repository.findById(id).map(calculator::toResult).orElse(null);
    }

    public List<FlightPlanResult> getAll() {
        return repository.findAll().stream().map(calculator::toResult).toList();
    }
}
