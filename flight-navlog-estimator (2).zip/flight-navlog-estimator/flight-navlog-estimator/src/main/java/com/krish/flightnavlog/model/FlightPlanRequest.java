package com.krish.flightnavlog.model;

import java.util.List;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

public class FlightPlanRequest {
    @NotBlank private String pilotName;
    @NotBlank private String departure;
    @NotBlank private String destination;
    @NotNull @Positive private Double cruiseTasKt;
    @NotNull @PositiveOrZero private Double windFromDeg;
    @NotNull @PositiveOrZero private Double windSpeedKt;
    @NotNull @DecimalMin("-180.0") @DecimalMax("180.0") private Double magneticVariationDeg;
    @NotNull @Positive private Double fuelBurnGph;
    @NotNull @PositiveOrZero private Integer reserveMinutes;
    @NotEmpty @Size(min = 2) private List<@Valid WaypointInput> waypoints;

    public FlightPlanRequest() {}
    public String getPilotName() { return pilotName; }
    public void setPilotName(String pilotName) { this.pilotName = pilotName; }
    public String getDeparture() { return departure; }
    public void setDeparture(String departure) { this.departure = departure; }
    public String getDestination() { return destination; }
    public void setDestination(String destination) { this.destination = destination; }
    public Double getCruiseTasKt() { return cruiseTasKt; }
    public void setCruiseTasKt(Double cruiseTasKt) { this.cruiseTasKt = cruiseTasKt; }
    public Double getWindFromDeg() { return windFromDeg; }
    public void setWindFromDeg(Double windFromDeg) { this.windFromDeg = windFromDeg; }
    public Double getWindSpeedKt() { return windSpeedKt; }
    public void setWindSpeedKt(Double windSpeedKt) { this.windSpeedKt = windSpeedKt; }
    public Double getMagneticVariationDeg() { return magneticVariationDeg; }
    public void setMagneticVariationDeg(Double magneticVariationDeg) { this.magneticVariationDeg = magneticVariationDeg; }
    public Double getFuelBurnGph() { return fuelBurnGph; }
    public void setFuelBurnGph(Double fuelBurnGph) { this.fuelBurnGph = fuelBurnGph; }
    public Integer getReserveMinutes() { return reserveMinutes; }
    public void setReserveMinutes(Integer reserveMinutes) { this.reserveMinutes = reserveMinutes; }
    public List<WaypointInput> getWaypoints() { return waypoints; }
    public void setWaypoints(List<WaypointInput> waypoints) { this.waypoints = waypoints; }
}
