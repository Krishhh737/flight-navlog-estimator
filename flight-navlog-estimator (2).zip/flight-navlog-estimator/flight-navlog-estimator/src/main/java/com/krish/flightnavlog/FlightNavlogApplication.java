package com.krish.flightnavlog;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FlightNavlogApplication {
    public static void main(String[] args) {
        SpringApplication.run(FlightNavlogApplication.class, args);
    }
}
