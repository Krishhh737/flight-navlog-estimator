package com.krish.flightnavlog.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.krish.flightnavlog.entity.FlightPlan;

public interface FlightPlanRepository extends JpaRepository<FlightPlan, Long> {}
