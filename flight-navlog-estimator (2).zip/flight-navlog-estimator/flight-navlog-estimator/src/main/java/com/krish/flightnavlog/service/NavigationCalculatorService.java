package com.krish.flightnavlog.service;

import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Service;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.krish.flightnavlog.entity.FlightPlan;
import com.krish.flightnavlog.model.*;

@Service
public class NavigationCalculatorService {
    private final ObjectMapper mapper;
    public NavigationCalculatorService(ObjectMapper mapper) { this.mapper = mapper; }

    public FlightPlanResult calculate(FlightPlanRequest request) {
        validate(request);
        List<WaypointInput> points = request.getWaypoints();
        List<LegResult> legs = new ArrayList<>();
        double totalDistance = 0, totalMinutes = 0, tripFuel = 0;

        for (int i = 0; i < points.size() - 1; i++) {
            WaypointInput a = points.get(i), b = points.get(i + 1);
            double distance = distanceNm(a.getLatitude(), a.getLongitude(), b.getLatitude(), b.getLongitude());
            double course = initialBearing(a.getLatitude(), a.getLongitude(), b.getLatitude(), b.getLongitude());
            double relativeWind = Math.toRadians(normalizeSigned(request.getWindFromDeg() - course));
            // Wind-from angle is relative to course. Crosswind component is windSpeed * sin(relativeWind).
            double crosswind = request.getWindSpeedKt() * Math.sin(relativeWind);
            double ratio = -crosswind / request.getCruiseTasKt();
            ratio = Math.max(-1.0, Math.min(1.0, ratio));
            double wca = Math.toDegrees(Math.asin(ratio));
            double trueHeading = normalize(course + wca);
            double alongTrackWind = -request.getWindSpeedKt() * Math.cos(relativeWind);
            double gs = request.getCruiseTasKt() * Math.cos(Math.toRadians(wca)) + alongTrackWind;
            if (gs <= 0) throw new IllegalArgumentException("Calculated ground speed is not positive; check wind/TAS inputs.");
            double ete = distance / gs * 60.0;
            double fuel = ete / 60.0 * request.getFuelBurnGph();
            // East variation is positive: magnetic = true - east variation.
            double magneticHeading = normalize(trueHeading - request.getMagneticVariationDeg());

            legs.add(new LegResult(a.getName(), b.getName(), round(distance), round(course),
                    round(wca), round(gs), round(trueHeading), round(magneticHeading),
                    round(ete), round(fuel)));
            totalDistance += distance; totalMinutes += ete; tripFuel += fuel;
        }

        double reserveFuel = request.getFuelBurnGph() * request.getReserveMinutes() / 60.0;
        FlightPlanResult result = new FlightPlanResult();
        result.setPilotName(request.getPilotName());
        result.setDeparture(request.getDeparture());
        result.setDestination(request.getDestination());
        result.setTotalDistanceNm(round(totalDistance));
        result.setTotalEteMinutes(round(totalMinutes));
        result.setTripFuelGallons(round(tripFuel));
        result.setReserveFuelGallons(round(reserveFuel));
        result.setTotalFuelRequiredGallons(round(tripFuel + reserveFuel));
        result.setLegs(legs);
        return result;
    }

    public FlightPlan saveEntity(FlightPlanRequest request, FlightPlanResult result) {
        FlightPlan entity = new FlightPlan();
        entity.setPilotName(result.getPilotName());
        entity.setDeparture(result.getDeparture());
        entity.setDestination(result.getDestination());
        entity.setTotalDistanceNm(result.getTotalDistanceNm());
        entity.setTotalEteMinutes(result.getTotalEteMinutes());
        entity.setTripFuelGallons(result.getTripFuelGallons());
        entity.setReserveFuelGallons(result.getReserveFuelGallons());
        entity.setTotalFuelRequiredGallons(result.getTotalFuelRequiredGallons());
        try {
            entity.setNavLogJson(mapper.writeValueAsString(result));
        } catch (JsonProcessingException e) {
            throw new IllegalStateException("Could not serialize navigation log", e);
        }
        return entity;
    }

    public FlightPlanResult toResult(FlightPlan entity) {
        try {
            FlightPlanResult result = mapper.readValue(entity.getNavLogJson(), FlightPlanResult.class);
            result.setId(entity.getId());
            return result;
        } catch (Exception e) {
            throw new IllegalStateException("Could not read stored navigation log", e);
        }
    }

    private void validate(FlightPlanRequest r) {
        if (r.getCruiseTasKt() == null || r.getCruiseTasKt() <= 0 ||
            r.getFuelBurnGph() == null || r.getFuelBurnGph() <= 0 ||
            r.getWindSpeedKt() == null || r.getWindSpeedKt() < 0 ||
            r.getWindFromDeg() == null || r.getWindFromDeg() < 0 || r.getWindFromDeg() > 360 ||
            r.getMagneticVariationDeg() == null ||
            r.getReserveMinutes() == null || r.getReserveMinutes() < 0 ||
            r.getWaypoints() == null || r.getWaypoints().size() < 2) {
            throw new IllegalArgumentException("Check TAS, wind, variation, fuel burn, reserve and at least two waypoints.");
        }
    }

    private double distanceNm(double lat1, double lon1, double lat2, double lon2) {
        double p1 = Math.toRadians(lat1), p2 = Math.toRadians(lat2);
        double dLat = Math.toRadians(lat2-lat1), dLon = Math.toRadians(lon2-lon1);
        double h = Math.pow(Math.sin(dLat/2),2) + Math.cos(p1)*Math.cos(p2)*Math.pow(Math.sin(dLon/2),2);
        return 3440.065 * 2 * Math.atan2(Math.sqrt(h), Math.sqrt(Math.max(0,1-h)));
    }

    private double initialBearing(double lat1, double lon1, double lat2, double lon2) {
        double p1=Math.toRadians(lat1), p2=Math.toRadians(lat2), dLon=Math.toRadians(lon2-lon1);
        double y=Math.sin(dLon)*Math.cos(p2);
        double x=Math.cos(p1)*Math.sin(p2)-Math.sin(p1)*Math.cos(p2)*Math.cos(dLon);
        return normalize(Math.toDegrees(Math.atan2(y,x)));
    }

    private double normalize(double d) { return ((d % 360) + 360) % 360; }
    private double normalizeSigned(double d) { return ((d + 540) % 360) - 180; }
    private double round(double x) { return Math.round(x * 100.0) / 100.0; }
}
