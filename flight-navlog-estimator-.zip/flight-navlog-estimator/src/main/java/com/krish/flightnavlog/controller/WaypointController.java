package com.krish.flightnavlog.controller;

import com.krish.flightnavlog.entity.Airport;
import com.krish.flightnavlog.repository.AirportRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@RestController
@RequestMapping("/api/waypoints")
public class WaypointController {

    private final AirportRepository airportRepository;

    public WaypointController(AirportRepository airportRepository) {
        this.airportRepository = airportRepository;
    }

    /**
     * Searches the imported airport dataset by identifier, airport name,
     * or municipality. Example: GET /api/waypoints?query=Ahmedabad
     */
    @GetMapping
    @Transactional(readOnly = true)
    public ResponseEntity<List<Airport>> searchWaypoints(
            @RequestParam(name = "query", required = false) String query) {

        if (query == null || query.isBlank()) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "The 'query' parameter is required. Example: /api/waypoints?query=Ahmedabad");
        }

        String searchTerm = query.trim();

        List<Airport> results =
                airportRepository
                        .findTop50ByIdentContainingIgnoreCaseOrNameContainingIgnoreCaseOrMunicipalityContainingIgnoreCase(
                                searchTerm, searchTerm, searchTerm);

        return ResponseEntity.ok(results);
    }
}
