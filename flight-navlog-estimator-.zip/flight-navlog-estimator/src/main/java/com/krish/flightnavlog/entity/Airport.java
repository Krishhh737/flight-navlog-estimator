package com.krish.flightnavlog.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

/**
 * Maps the public OurAirports CSV dataset to the MySQL "airports" table.
 * Column names intentionally match the source CSV headers.
 */
@Entity
@Table(name = "airports")
public class Airport {

    @Id
    @Column(name = "id", nullable = false)
    private Long id;

    @Column(name = "ident", length = 20)
    private String ident;

    @Column(name = "type", length = 50)
    private String type;

    @Column(name = "name", length = 255)
    private String name;

    @Column(name = "latitude_deg")
    private Double latitudeDeg;

    @Column(name = "longitude_deg")
    private Double longitudeDeg;

    @Column(name = "elevation_ft")
    private Integer elevationFt;

    @Column(name = "continent", length = 2)
    private String continent;

    @Column(name = "iso_country", length = 2)
    private String isoCountry;

    @Column(name = "iso_region", length = 10)
    private String isoRegion;

    @Column(name = "municipality", length = 100)
    private String municipality;

    @Column(name = "scheduled_service", length = 10)
    private String scheduledService;

    @Column(name = "gps_code", length = 20)
    private String gpsCode;

    @Column(name = "iata_code", length = 10)
    private String iataCode;

    @Column(name = "local_code", length = 20)
    private String localCode;

    @Column(name = "home_link", length = 2000)
    private String homeLink;

    @Column(name = "wikipedia_link", length = 2000)
    private String wikipediaLink;

    @Column(name = "keywords", columnDefinition = "TEXT")
    private String keywords;

    public Airport() {
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getIdent() { return ident; }
    public void setIdent(String ident) { this.ident = ident; }

    public String getType() { return type; }
    public void setType(String type) { this.type = type; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public Double getLatitudeDeg() { return latitudeDeg; }
    public void setLatitudeDeg(Double latitudeDeg) { this.latitudeDeg = latitudeDeg; }

    public Double getLongitudeDeg() { return longitudeDeg; }
    public void setLongitudeDeg(Double longitudeDeg) { this.longitudeDeg = longitudeDeg; }

    public Integer getElevationFt() { return elevationFt; }
    public void setElevationFt(Integer elevationFt) { this.elevationFt = elevationFt; }

    public String getContinent() { return continent; }
    public void setContinent(String continent) { this.continent = continent; }

    public String getIsoCountry() { return isoCountry; }
    public void setIsoCountry(String isoCountry) { this.isoCountry = isoCountry; }

    public String getIsoRegion() { return isoRegion; }
    public void setIsoRegion(String isoRegion) { this.isoRegion = isoRegion; }

    public String getMunicipality() { return municipality; }
    public void setMunicipality(String municipality) { this.municipality = municipality; }

    public String getScheduledService() { return scheduledService; }
    public void setScheduledService(String scheduledService) { this.scheduledService = scheduledService; }

    public String getGpsCode() { return gpsCode; }
    public void setGpsCode(String gpsCode) { this.gpsCode = gpsCode; }

    public String getIataCode() { return iataCode; }
    public void setIataCode(String iataCode) { this.iataCode = iataCode; }

    public String getLocalCode() { return localCode; }
    public void setLocalCode(String localCode) { this.localCode = localCode; }

    public String getHomeLink() { return homeLink; }
    public void setHomeLink(String homeLink) { this.homeLink = homeLink; }

    public String getWikipediaLink() { return wikipediaLink; }
    public void setWikipediaLink(String wikipediaLink) { this.wikipediaLink = wikipediaLink; }

    public String getKeywords() { return keywords; }
    public void setKeywords(String keywords) { this.keywords = keywords; }
}
