package com.krish.flightnavlog.repository;

import com.krish.flightnavlog.entity.Airport;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AirportRepository extends JpaRepository<Airport, Long> {

    List<Airport> findTop50ByIdentContainingIgnoreCaseOrNameContainingIgnoreCaseOrMunicipalityContainingIgnoreCase(
            String ident, String name, String municipality);
}
