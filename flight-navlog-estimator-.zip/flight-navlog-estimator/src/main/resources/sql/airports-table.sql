-- Run this in MySQL Workbench before importing OurAirports airports.csv.
-- Database name must match application.properties: flight_navlog_db

CREATE DATABASE IF NOT EXISTS flight_navlog_db;
USE flight_navlog_db;

CREATE TABLE IF NOT EXISTS airports (
    id BIGINT NOT NULL PRIMARY KEY,
    ident VARCHAR(20),
    type VARCHAR(50),
    name VARCHAR(255),
    latitude_deg DOUBLE,
    longitude_deg DOUBLE,
    elevation_ft INT,
    continent VARCHAR(2),
    iso_country VARCHAR(2),
    iso_region VARCHAR(10),
    municipality VARCHAR(100),
    scheduled_service VARCHAR(10),
    gps_code VARCHAR(20),
    iata_code VARCHAR(10),
    local_code VARCHAR(20),
    home_link VARCHAR(2000),
    wikipedia_link VARCHAR(2000),
    keywords TEXT
);
