# Desktop Flight Plan Navigation Log & Fuel Burn Estimator

A Java and Spring Boot educational project for creating and retrieving flight plans, estimating multi-leg navigation data, calculating approximate fuel requirements, and exposing REST and SOAP services backed by MySQL.

> **Safety note:** This is an educational prototype only. Its simplified calculations and sample reserve settings are not validated for real-world flight operations. Do not use it for actual flight planning or aircraft operation.

## Features

- Create and save flight plans through a REST API.
- Retrieve one saved flight plan or list saved plans.
- Estimate great-circle distance, true course, wind correction, groundspeed, true heading, magnetic heading, ETE, and fuel burn for each leg.
- Calculate total distance, trip time, trip fuel, reserve fuel, and estimated total fuel.
- Store flight-plan data in MySQL using Spring Data JPA/Hibernate.
- Expose a SOAP endpoint for retrieving a saved flight plan.
- Search airport records from an imported airport CSV dataset through `GET /api/waypoints?query=...` (requires CSV import into MySQL).

## Technology Stack

- Java 17
- Spring Boot 3.4.5
- Maven
- Spring Web (REST APIs)
- Spring Data JPA / Hibernate
- MySQL
- Spring Web Services (SOAP)
- Postman
- Eclipse IDE or Spring Tool Suite

## Prerequisites

1. JDK 17
2. Maven (or Maven integration in Eclipse/STS)
3. MySQL Server and MySQL Workbench
4. Postman for API testing
5. Git for GitHub submission

## Database Setup

The application uses the MySQL database `flight_navlog_db`.

1. Open `src/main/resources/application.properties`.
2. Set your local MySQL username and password. Example:

```properties
spring.datasource.url=jdbc:mysql://localhost:3306/flight_navlog_db?createDatabaseIfNotExist=true
spring.datasource.username=root
spring.datasource.password=YOUR_LOCAL_PASSWORD
spring.datasource.driver-class-name=com.mysql.cj.jdbc.Driver

spring.jpa.hibernate.ddl-auto=update
spring.jpa.show-sql=true
spring.jpa.properties.hibernate.format_sql=true
server.port=8080
```

**Security:** Never commit your real database password to GitHub. Keep credentials local or use environment variables/secrets.

### Create the airport table

Run `src/main/resources/sql/airports-table.sql` in MySQL Workbench. This creates the `flight_navlog_db` database and `airports` table. Hibernate creates or updates the flight-plan table.

### Import airport data

The airport-search endpoint returns records only after the CSV has been imported.

1. Download `airports.csv` from the [OurAirports data page](https://ourairports.com/data/).
2. In MySQL Workbench, select `flight_navlog_db`.
3. Use **Table Data Import Wizard** on the existing `airports` table.
4. Map the CSV columns to matching table columns, including `id`.
5. Verify the import:

```sql
USE flight_navlog_db;
SELECT COUNT(*) AS total_airports FROM airports;
SELECT ident, name, latitude_deg, longitude_deg, municipality
FROM airports
LIMIT 10;
```

The dataset is not included in this repository. Check the current CSV headers and usage terms before importing or redistributing it.

## Run the Application

### Eclipse / Spring Tool Suite

1. Extract or clone the project.
2. Select **File → Import → Maven → Existing Maven Projects**.
3. Select the project folder containing `pom.xml`.
4. Finish the import and run **Maven → Update Project**.
5. Configure your MySQL credentials.
6. Run `FlightNavlogApplication.java` as a Java Application or Spring Boot App.
7. Confirm that the app starts on port `8080`.

### Terminal

From the project root (where `pom.xml` is located):

```bash
mvn spring-boot:run
```

The app should be available at `http://localhost:8080`.

## REST API Endpoints

### Create and save a flight plan

`POST http://localhost:8080/api/flight-plans`

Example JSON:

```json
{
  "pilotName": "Student Pilot",
  "departure": "VAAH",
  "destination": "VABO",
  "cruiseTasKt": 105,
  "windFromDeg": 270,
  "windSpeedKt": 12,
  "magneticVariationDeg": 1.5,
  "fuelBurnGph": 8.5,
  "reserveMinutes": 30,
  "waypoints": [
    {"name": "VAAH", "latitude": 23.077, "longitude": 72.634},
    {"name": "Waypoint A", "latitude": 22.8, "longitude": 72.9},
    {"name": "VABO", "latitude": 22.336, "longitude": 73.226}
  ]
}
```

Expected success status: `201 Created`. The response should include the saved plan ID and calculated navigation results.

### List saved plans

`GET http://localhost:8080/api/flight-plans`

### Retrieve one saved plan

`GET http://localhost:8080/api/flight-plans/{id}`

Replace `{id}` with an ID returned by the POST request.

### Search imported airport records

`GET http://localhost:8080/api/waypoints?query=Ahmedabad`

Searches by airport identifier, name, or municipality. The CSV must be imported into the `airports` table first. A valid search with no matches returns `200 OK` and an empty array; a missing/blank query returns `400 Bad Request`.

## SOAP Web Service

- WSDL: `http://localhost:8080/ws/flightPlan.wsdl`
- Endpoint: `POST http://localhost:8080/ws`
- Content-Type: `text/xml; charset=utf-8`

Example SOAP request (replace `1` with an existing flight-plan ID):

```xml
<?xml version="1.0" encoding="UTF-8"?>
<soapenv:Envelope
    xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"
    xmlns:fl="http://krish.com/flightnavlog/soap">
  <soapenv:Header/>
  <soapenv:Body>
    <fl:getFlightPlanRequest>
      <fl:id>1</fl:id>
    </fl:getFlightPlanRequest>
  </soapenv:Body>
</soapenv:Envelope>
```

## Calculation Overview

- Great-circle distance uses the haversine formula.
- `ETE (minutes) = distance (NM) / groundspeed (knots) × 60`.
- `Trip fuel = ETE (minutes) / 60 × fuel burn (gallons/hour)`.
- `Reserve fuel = fuel burn (gallons/hour) × reserve minutes / 60`.
- `Total estimated fuel = trip fuel + reserve fuel`.
- Magnetic heading adjusts true heading by magnetic variation (east variation is treated as positive).

Wind and heading computations are simplified educational estimates and have not been validated for operational aviation use.

## Verify Database Records

```sql
USE flight_navlog_db;
SELECT * FROM flight_plans;
SELECT COUNT(*) AS total_airports FROM airports;
```

## Known Limitations

- Waypoints for flight-plan creation are entered manually; airport search is a separate endpoint and is not automatically connected to the flight-plan input flow.
- Airport search requires importing the external CSV into MySQL.
- The project does not currently provide a complete VOR database or airway-route dataset.
- There is no graphical user interface.
- Flight calculations are simplified and must not be used for actual flight planning.
- The airport CSV is not bundled in this repository.

## GitHub Setup

Create a new repository on GitHub. From the project root, run:

```bash
git init
git add .
git commit -m "Add flight navigation log estimator"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/flight-navlog-estimator.git
git push -u origin main
```

Replace the example remote URL with your real repository URL. If you already cloned a repository, do not run `git init` again; commit and push your changes instead. Never upload passwords, API keys, or other secrets.

## Author

Krish Modi

## Disclaimer

This software is intended for academic demonstration and learning purposes only. It is not certified, approved, or suitable for real-world flight planning, dispatch, or aircraft operation.
